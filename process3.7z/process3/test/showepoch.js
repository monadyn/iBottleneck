console.log(new Date(1432781520650));

console.log('1432781520650');
var str = "2015-05-27T21:52:00";
var et = new Date(str).getTime();
console.log(et + 18000000);
